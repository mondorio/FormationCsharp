﻿using System.Windows;

namespace Or
{
    /// <summary>
    /// Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
